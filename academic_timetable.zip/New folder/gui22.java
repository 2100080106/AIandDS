	
class gui22
{
public static void main(String arg[])
{ 
starte s1=new starte();
}
}
	
